$('#admin').click(function()
{
	location.reload(true);
}
);